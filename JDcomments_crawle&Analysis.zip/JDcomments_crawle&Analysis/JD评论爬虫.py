import requests
import json
import pymysql



class Jdspider(object):
    def __init__(self):
        self.url='http://sclub.jd.com/comment/productPageComments.action?'
        self.headers = {'User-Agent': 'Mozilla/5.0'}
        self.db=pymysql.connect(host='127.0.0.1', port=3306, user='root', password='1234', db='jd', charset='utf8')
        self.cursor=self.db.cursor()

    # 获取页面
    def getPage(self, params):
        res = requests.get(self.url, params=params,
                           headers=self.headers)
        # res.encoding = 'utf-8'
        print(res.url)
        html = res.text
        self.parsePage(html)

    # 解析和打印
    def parsePage(self, html):
        data = json.loads(html)
        for comment in data['comments']:
            product_name = comment['referenceName']
            comment_time = comment['creationTime']
            content = comment['content']
            id=comment['referenceId']
            L=[id,product_name,comment_time,content]
            self.writeMysql(L)

    def writeMysql(self,L):
        ins='insert into jd.jd_items (skuid, productName,commentTime,content) values (%s,%s,%s,%s) '
        self.cursor.execute(ins,L)
        self.db.commit()


    def workOn(self):
        i=1
        try:
            for n in range(100,101):
                params = {'productId': '1082266',
                          'score': '0',
                          'sortType': '5',
                          'page': str(n),
                          'pageSize': '10',
                          'isShadowSku': '0',
                          'rid': '0',
                          'fold': '1'
                          }
                i+=n
                # print("第"+i+'页保存完成')
                self.getPage(params)
        except Exception as err:
            print(err)

        self.cursor.close()
        self.db.close()


if __name__ == '__main__':
    spider = Jdspider()
    spider.workOn()











